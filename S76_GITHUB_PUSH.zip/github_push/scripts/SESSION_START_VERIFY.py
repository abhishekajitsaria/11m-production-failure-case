#!/usr/bin/env python3
"""
SESSION_START_VERIFY.py — Mandatory first action of every new WOS session.

Runs every safety check in one shot. Produces PASS/FAIL summary.

Usage at session start (next Claude pastes this):
    python3 /mnt/project/SESSION_START_VERIFY.py

Exit codes:
    0  → all checks PASS or only WARN
    1  → at least one CHECK failed — STOP, surface findings, do not edit until reconciled
"""

import hashlib, os, re, sys, time, zipfile
from datetime import datetime, timezone
from pathlib import Path

PROJECT = Path("/mnt/project")
HOME = Path("/home/claude")
REGISTRY = PROJECT / "WOS_CENTRAL_REGISTRY_v20_s52r5.xlsx"

PASS = "\033[92mPASS\033[0m"
FAIL = "\033[91mFAIL\033[0m"
WARN = "\033[93mWARN\033[0m"

results = []

PARA_RE = re.compile(r"<(?:w|ns\d+):p[\s/>]")
INS_RE = re.compile(r"<(?:w|ns\d+):ins[\s>]")
DEL_RE = re.compile(r"<(?:w|ns\d+):del[\s>]")

EDITION_MAP = {
    "POST": "BOOK1_POST", "PRE": "BOOK1_PRE",
    "REW": "BOOK1_REWRITE", "REWRITE": "BOOK1_REWRITE",
    "ENG": "BOOK2_ENGLISH", "BI": "BOOK2_BILINGUAL", "HIN": "BOOK2_HINGLISH",
}

CLAIM_RE = re.compile(r"(POST|PRE|REW|REWRITE|ENG|BI|HIN)\s+v([0-9_]+)\s*\(([0-9a-f]{8})(?:[^)]*)?\)")

def sha8(path):
    if not path.exists(): return None
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""): h.update(chunk)
    return h.hexdigest()[:8]

def header(text):
    print(f"\n{'='*70}\n{text}\n{'='*70}")

def record(check_id, status, detail):
    results.append((check_id, status, detail))
    print(f"  [{status}] {check_id}: {detail}")

# J1
header("J1 — touch-test (write permission to /mnt/project/)")
test = PROJECT / ".session_verify_test"
try:
    test.write_text("ok"); test.unlink()
    record("J1", PASS, "/mnt/project/ is writable")
except Exception as e:
    record("J1", FAIL, f"NOT writable: {e}")

# S444
header("S444 — VM-cycle awareness (init boot time vs registry mtime)")
try:
    with open("/proc/uptime") as f: uptime_sec = float(f.read().split()[0])
    boot_time = datetime.fromtimestamp(time.time() - uptime_sec, tz=timezone.utc)
    print(f"  init (PID 1) start time: {boot_time}  ({uptime_sec/60:.1f} min ago)")
    if REGISTRY.exists():
        reg_mtime = datetime.fromtimestamp(REGISTRY.stat().st_mtime, tz=timezone.utc)
        print(f"  registry mtime:          {reg_mtime}")
        delta_min = (boot_time - reg_mtime).total_seconds() / 60.0
        if delta_min > 0:
            record("S444", WARN, f"VM booted {delta_min:.1f} min AFTER registry's last update — VM cycle has occurred. Run S442 carefully.")
        else:
            record("S444", PASS, f"VM boot precedes registry update by {-delta_min:.1f} min — same-VM continuity")
    else:
        record("S444", FAIL, "Registry not found")
except Exception as e:
    record("S444", WARN, f"Could not determine boot time: {e}")

# S443
header("S443 — Registry-as-source-of-truth (latest 'Ending Files' SHAs)")
canonical = {}  # full_filename -> (claimed_sha, row)
try:
    import openpyxl
    wb = openpyxl.load_workbook(REGISTRY, data_only=False)
    ws = wb["Sessions_Detail"]

    sha_to_file = {}
    for f in PROJECT.glob("BOOK*.docx"):
        sha_to_file[sha8(f)] = f.name

    last_row = ws.max_row
    parsed_claims = {}
    for r in range(last_row, max(1, last_row - 20), -1):
        ending = ws.cell(r, 6).value
        if not ending: continue
        ending_str = str(ending)
        if "manuscript files unchanged" in ending_str.lower(): continue
        for m in CLAIM_RE.finditer(ending_str):
            short, ver, sha = m.group(1), m.group(2), m.group(3)
            book_prefix = EDITION_MAP.get(short)
            if not book_prefix: continue
            full_fn = f"{book_prefix}_v{ver}.docx"
            if full_fn not in parsed_claims:
                parsed_claims[full_fn] = (sha, r)
        # don't break — keep aggregating older rows to fill in claims for editions not in newer rows

    # Reduce parsed_claims to just LATEST version per book (older versions may have been deleted pre-S316)
    by_book_latest = {}
    for fn, (sha, row) in parsed_claims.items():
        m = re.match(r"(BOOK[12]_[A-Z]+)_v([0-9_]+)\.docx", fn)
        if not m: continue
        book = m.group(1)
        ver = tuple(int(x) for x in m.group(2).split("_"))
        if book not in by_book_latest or ver > by_book_latest[book][2]:
            by_book_latest[book] = (fn, sha, ver, row)

    if not by_book_latest:
        record("S443", WARN, "Could not parse manuscript SHAs from any of the last 20 registry rows")
    else:
        all_match = True
        for book in sorted(by_book_latest.keys()):
            fn, claimed_sha, _, row = by_book_latest[book]
            actual = sha8(PROJECT / fn)
            if actual == claimed_sha:
                print(f"  [{PASS}] {fn}: {claimed_sha} matches at /mnt/project/ (row {row})")
                canonical[fn] = (claimed_sha, row)
            elif claimed_sha in sha_to_file:
                print(f"  [{WARN}] {fn}: SHA {claimed_sha} found at {sha_to_file[claimed_sha]} not at expected {fn} (row {row})")
            else:
                print(f"  [{FAIL}] {fn}: row {row} claims {claimed_sha}, MISSING — STOP, this is the canonical latest version")
                all_match = False
        if all_match:
            record("S443", PASS, f"All {len(by_book_latest)} latest-canonical manuscripts match registry")
        else:
            record("S443", FAIL, "Latest-canonical manuscript mismatch — STOP, reconcile")
except Exception as e:
    record("S443", FAIL, f"Registry read error: {e}")

# S442
header("S442 — /home/claude/ mirror-check (uncommitted prior-VM work)")
try:
    home_files = sorted(list(HOME.glob("*.docx")) + list(HOME.glob("*.xlsx")))
    if not home_files:
        record("S442", PASS, "/home/claude/ has no manuscript files — clean state")
    else:
        wb = openpyxl.load_workbook(REGISTRY, data_only=False)
        ws = wb["Sessions_Detail"]
        registry_shas = set()
        for r in range(2, ws.max_row + 1):
            for col in (5, 6):
                v = ws.cell(r, col).value
                if v: registry_shas.update(re.findall(r"[0-9a-f]{8}", str(v)))
        unaccounted = []
        for f in home_files:
            s = sha8(f)
            in_registry = s in registry_shas
            in_project = (PROJECT / f.name).exists() and sha8(PROJECT / f.name) == s
            sw = "registered" if in_registry else "UNCOMMITTED"
            mr = "in /mnt/project/" if in_project else "NOT in /mnt/project/"
            print(f"  {f.name}: {s} ({sw}, {mr})")
            if not in_registry: unaccounted.append((f.name, s))
        if unaccounted:
            record("S442", FAIL, f"{len(unaccounted)} uncommitted file(s): {unaccounted}")
        else:
            record("S442", PASS, f"All {len(home_files)} /home/claude/ files have SHAs in registry history")
except Exception as e:
    record("S442", FAIL, f"Mirror-check error: {e}")

# INTEGRITY
header("CONTENT INTEGRITY — tracked changes + paragraph count")
try:
    files_to_check = list(canonical.keys()) if canonical else sorted([f.name for f in PROJECT.glob("BOOK*.docx")])
    integrity_ok = True
    for fn in sorted(files_to_check):
        path = PROJECT / fn
        if not path.exists():
            print(f"  [{WARN}] {fn}: not found")
            continue
        try:
            with zipfile.ZipFile(path) as z:
                xml = z.read("word/document.xml").decode("utf-8", errors="ignore")
                ins = len(INS_RE.findall(xml))
                dele = len(DEL_RE.findall(xml))
                paras = len(PARA_RE.findall(xml))
                if ins == 0 and dele == 0 and paras > 0:
                    print(f"  [{PASS}] {fn}: 0 tracked changes, {paras:,} paragraphs")
                elif paras == 0:
                    print(f"  [{FAIL}] {fn}: paragraph count is 0 — file may be corrupt")
                    integrity_ok = False
                else:
                    print(f"  [{FAIL}] {fn}: ins={ins}, del={dele}, paras={paras}")
                    integrity_ok = False
        except (KeyError, zipfile.BadZipFile) as e:
            print(f"  [{FAIL}] {fn}: file unreadable — {e}")
            integrity_ok = False
    if integrity_ok:
        record("INTEGRITY", PASS, f"All {len(files_to_check)} manuscripts pass integrity check")
    else:
        record("INTEGRITY", FAIL, "One or more manuscripts failed integrity check")
except Exception as e:
    record("INTEGRITY", FAIL, f"Integrity check error: {e}")

# SUMMARY
header("VERIFICATION SUMMARY")
n_fail = sum(1 for _, s, _ in results if FAIL in s)
n_warn = sum(1 for _, s, _ in results if WARN in s)
n_pass = sum(1 for _, s, _ in results if PASS in s)
print(f"  {n_pass} PASS / {n_warn} WARN / {n_fail} FAIL\n")

if n_fail > 0:
    print(f"  ⛔ {FAIL}: at least one check failed — DO NOT proceed with edits.")
    print(f"     Surface findings to author and reconcile before any new manuscript work.")
    sys.exit(1)
elif n_warn > 0:
    print(f"  ⚠  {WARN}: warnings present — review before proceeding.")
    print(f"     S444 WARN = VM cycle detected; review S442 + S443 carefully.")
    sys.exit(0)
else:
    print(f"  ✅ All checks {PASS} — safe to resume normal work.")
    sys.exit(0)
