"""
WOS PROMPTS v3.3 — BOOK 2 PROFILE [S52 patched + S49b D3 re-spliced]
Structural checks + Book 2-specific validations.
Book 2 is "The ₹500 Start" — 15 chapters ≥4,500w, unique characters per chapter.

v3.3 [S52, April 29 2026]: Detector parity with Book 1 v3.10.3.
  - D1 mid-word truncations: short-tail (1-3 char), article/preposition end,
    EXACT-500-CHAR PIPELINE TRUNCATION (TRUNC500 signature).
  - D6-A content duplicate: ≥50 chars exact-text match, Title/Subtitle excluded.
  - D6-C H1+BT migration residue: heading-style + identical Body Text within
    5 paragraphs, length-independent.
Defect classes ported verbatim from sandbox-tested Book 1 v3.10.3 (sandbox
validation: REWRITE v4_69 H1+BT residues at p1166/p1168 + p1857/p1859, both
caught and fixed S52). Logic is content-agnostic; applies identically to
Book 2 narrative-mode paragraphs.

Usage: python3 WOS_PROMPTS_BOOK2_TEST.py <file.docx>
"""
import sys, re, hashlib
from docx import Document
from collections import Counter

if len(sys.argv) < 2:
    print("Usage: WOS_PROMPTS_BOOK2_TEST.py <file.docx>")
    sys.exit(1)

fname = sys.argv[1]
doc = Document(fname)
paras = doc.paragraphs

with open(fname, 'rb') as f:
    raw = f.read()
sha = hashlib.sha256(raw).hexdigest()[:8]

# ─────────────────────────────────────────────────────────────────────
# PROMPT 1: QC 22-POINT (STRUCTURAL) — same checks as Book 1
# ─────────────────────────────────────────────────────────────────────
print("=" * 60)
print("PROMPT 1: QC 22-POINT (STRUCTURAL)")
print("=" * 60)

qc_results = {}

# Word count
text_lines = [p.text for p in paras if p.text.strip()]
total_words = sum(len(l.split()) for l in text_lines)
qc_results['Word count'] = ('PASS', total_words)

# Paragraphs
qc_results['Paragraph count'] = ('PASS', len(paras))

# Headings
h1 = len([p for p in paras if p.style and 'Heading 1' in p.style.name])
h2 = len([p for p in paras if p.style and 'Heading 2' in p.style.name])
h3 = len([p for p in paras if p.style and 'Heading 3' in p.style.name])
qc_results['H1 / H2 / H3'] = ('PASS' if h1+h2+h3 > 0 else 'FAIL', f"{h1}/{h2}/{h3}")

# Normal style (should be 0 — all body text in Body Text style)
normal = len([p for p in paras if p.style and p.style.name == 'Normal'])
qc_results['Normal style paragraphs (should be 0)'] = ('PASS' if normal == 0 else 'FAIL', normal)

# Tables
qc_results['Tables'] = ('PASS', len(doc.tables))

# Tracked changes — raw XML scan
xml = raw.decode('utf-8', errors='ignore')
w_del = xml.count('<w:del ')
w_ins = xml.count('<w:ins ')
qc_results['Tracked changes w:del (should be 0)'] = ('PASS' if w_del == 0 else 'FAIL', w_del)
qc_results['Tracked changes w:ins (should be 0)'] = ('PASS' if w_ins == 0 else 'FAIL', w_ins)

# Stutter check (repeated words)
all_text = ' '.join(text_lines)
stutter = len(re.findall(r'\b(\w+)\s+\1\b', all_text, re.IGNORECASE))
qc_results['Stutters (the the, etc.)'] = ('PASS' if stutter < 5 else 'WATCH', stutter)

# Blank paragraphs with whitespace only
blanks = len([p for p in paras if not p.text.strip() and p.text != ''])
qc_results['Pseudo-blank paragraphs'] = ('PASS' if blanks < 10 else 'WATCH', blanks)

# Comments
comments = xml.count('<w:comment ')
qc_results['Comments (should be 0)'] = ('PASS' if comments == 0 else 'FAIL', comments)

# Bookmarks
bookmarks = xml.count('<w:bookmarkStart ')
qc_results['Bookmarks'] = ('PASS', bookmarks)

# Sections
sections = xml.count('<w:sectPr')
qc_results['Section breaks'] = ('PASS', sections)

# File size
size_mb = len(raw) / (1024*1024)
qc_results['File size (MB)'] = ('PASS', f"{size_mb:.2f}")

# More sentinel checks (to reach 22 total)
has_title = any('Title' in (p.style.name or '') for p in paras)
qc_results['Title style present'] = ('PASS' if has_title or h1 > 0 else 'WATCH', has_title)

rsid_count = xml.count('rsidR')
qc_results['rsidR markers'] = ('PASS' if rsid_count < 1000 else 'WATCH', rsid_count)

# Junk control chars — body scope only (S426 fix, May 6 2026):
# Previously counted \x0b/\x0c across the raw DOCX ZIP bytes, which captured
# deflate-stream bytes from theme XML, settings, and embedded font tables
# as "junk content chars" (false-positive PATTERN-class detector artifact;
# baseline 1520 hits on v27, 1618 on v30 — pre-existing across all editions).
# Correct scope: scan only document body text (paragraph runs), not the ZIP
# bytestream. \x0b/\x0c are forbidden in document body content but legitimate
# inside ZIP-compressed sub-streams. Matches Book 1 detector v3.10.4 scope.
body_text = '\n'.join(p.text for p in paras)
junk_chars = sum(body_text.count(c) for c in ['\x0b', '\x0c'])
qc_results['Junk control chars'] = ('PASS' if junk_chars == 0 else 'FAIL', junk_chars)

fields = xml.count('<w:fldChar')
qc_results['Field codes'] = ('PASS', fields)

drawings = xml.count('<w:drawing')
qc_results['Drawings'] = ('PASS', drawings)

instrtext = xml.count('<w:instrText')
qc_results['Instruction text'] = ('PASS', instrtext)

footnotes = xml.count('<w:footnoteReference')
qc_results['Footnote references'] = ('PASS', footnotes)

endnotes = xml.count('<w:endnoteReference')
qc_results['Endnote references'] = ('PASS', endnotes)

hyperlinks = xml.count('<w:hyperlink')
qc_results['Hyperlinks'] = ('PASS', hyperlinks)

# Print
for check, (status, val) in qc_results.items():
    print(f"  {check}: {status} ({val})")

qc_pass = sum(1 for s, _ in qc_results.values() if s == 'PASS')
qc_total = len(qc_results)
qc_failed = [k for k, (s, _) in qc_results.items() if s != 'PASS']
print(f"\nQC RESULT: {qc_pass}/{qc_total} PASS")
if qc_failed:
    print(f"  NOT-PASS: {qc_failed}")

# ─────────────────────────────────────────────────────────────────────
# PROMPT 2B: BOOK 2 SPECIFIC — 15 chapters ≥4,500w + character diversity
# ─────────────────────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("PROMPT 2B: BOOK 2 CHAPTER STRUCTURE + DIVERSITY")
print("=" * 60)

# Find chapter boundaries
chapters = []  # list of (chapter_num, start_para_idx, end_para_idx)
current = None
for i, p in enumerate(paras):
    t = p.text.strip()
    m = re.match(r'^(?:CHAPTER|Chapter)\s+(\d+)(?:[:\s]|$)', t)
    if m and p.style and 'Heading' in (p.style.name or ''):
        if current is not None:
            chapters.append((current[0], current[1], i - 1))
        current = (int(m.group(1)), i)
if current is not None:
    chapters.append((current[0], current[1], len(paras) - 1))

print(f"Chapters found: {len(chapters)}")

# Check each chapter has ≥4,500 words
chapter_wc_pass = 0
chapter_details = []
for ch_num, start, end in chapters:
    ch_text = ' '.join(p.text for p in paras[start:end+1])
    wc = len(ch_text.split())
    passes = wc >= 4500
    if passes: chapter_wc_pass += 1
    chapter_details.append((ch_num, wc, passes))
    status = '✅' if passes else '❌'
    print(f"  {status} Chapter {ch_num}: {wc:,} words {'≥ 4,500' if passes else '< 4,500'}")

print(f"\nCHAPTER WORD COUNT: {chapter_wc_pass}/{len(chapters)} chapters ≥4,500w")

# Character name diversity — extract capitalized proper nouns per chapter
# Common Indian names (partial list for detection; avoids false positives from common words)
def extract_names(text):
    # Strategy: capitalized words of 3+ chars that appear >=2 times in chapter
    # (casual mentions of a capitalized word once likely aren't named characters;
    # named characters recur throughout their chapter)
    # Then filter by context: must appear as subject (followed by verb) OR with possessive 's
    candidates = Counter()
    # Subject pattern: "Name VERB" (common verbs)
    verbs = r'(?:said|was|were|is|are|had|has|went|asked|replied|thought|felt|walked|sat|stood|remembered|decided|realized|wondered|turned|looked|smiled|laughed|nodded|shook|opened|closed|took|gave|came|ran|went|saw|heard|knew|believed|wanted|needed|tried|started|finished|began|continued|stopped|spoke|told|called|watched|noticed|paused|stepped|moved|followed|entered|left|returned|arrived|checked|counted|calculated|wrote|read|picked|put|held|carried|pulled|pushed|opened|closed|waited|hesitated|answered|replied|explained|whispered|shouted|shrugged|sighed|breathed|paused|glanced|stared|winced|blinked|frowned|grimaced|grinned|chuckled|gasped|muttered|murmured|declared|announced|confirmed|agreed|disagreed|argued|insisted|suggested|offered|accepted|refused|rejected|approved|disapproved)'
    for m in re.finditer(rf'\b([A-Z][a-z]{{2,}})\s+{verbs}\b', text):
        candidates[m.group(1)] += 1
    # Possessives
    for m in re.finditer(r"\b([A-Z][a-z]{2,})'s\b", text):
        candidates[m.group(1)] += 1
    # Return names that appear 2+ times (named characters, not incidental mentions)
    return {n for n, c in candidates.items() if c >= 2}

# Common non-name capitalizations to exclude
EXCLUDE = {'The', 'This', 'That', 'But', 'And', 'Her', 'His', 'She', 'He', 'Their',
           'They', 'What', 'When', 'Where', 'Why', 'How', 'If', 'Mumbai', 'Delhi',
           'India', 'Bank', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul',
           'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Monday', 'Tuesday', 'Wednesday',
           'Thursday', 'Friday', 'Saturday', 'Sunday', 'Rupees', 'Lakh', 'Crore',
           'Here', 'There', 'You', 'Your', 'Then', 'Now', 'Today', 'Yesterday',
           'Tomorrow', 'Week', 'Month', 'Year', 'One', 'Two', 'Three', 'Four',
           'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Everyone', 'Someone',
           'Anyone', 'Nobody', 'Something', 'Anything', 'Nothing', 'Everyone',
           'Chapter', 'Book', 'Page', 'God', 'Allah', 'Ram', 'Hindi', 'English',
           'Yes', 'No', 'Ok', 'Okay', 'Maybe', 'Perhaps', 'Sure', 'Well', 'Just',
           'Even', 'Only', 'First', 'Last', 'Next', 'Later', 'After', 'Before',
           'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata', 'Pune', 'Hyderabad'}

chapter_names = []
for ch_num, start, end in chapters:
    ch_text = ' '.join(p.text for p in paras[start:end+1])
    names = extract_names(ch_text) - EXCLUDE
    chapter_names.append((ch_num, names))

# Character diversity: do chapters share protagonists?
# A properly diversified Book 2 should have <=3 overlapping names between any pair of chapters
print("\nCharacter diversity check (overlap between chapters):")
name_freq = Counter()
for _, names in chapter_names:
    for n in names:
        name_freq[n] += 1

# Names appearing in 5+ chapters (possible recurring cast — not diversified)
recurring = [(n, c) for n, c in name_freq.most_common() if c >= 5]
print(f"  Names appearing in 5+ chapters (should be 0 for diversified edition):")
if recurring:
    for n, c in recurring[:10]:
        print(f"    {n}: {c} chapters")
    diversity_status = 'WATCH'
else:
    print(f"    None — good diversification")
    diversity_status = 'PASS'

# Names appearing in 3-4 chapters
mid_recurring = [(n, c) for n, c in name_freq.most_common() if 3 <= c <= 4]
print(f"\n  Names appearing in 3-4 chapters: {len(mid_recurring)}")
for n, c in mid_recurring[:5]:
    print(f"    {n}: {c} chapters")

# ─────────────────────────────────────────────────────────────────────
# PROMPT 3: CROSS-REFS + HYPHENATION
# ─────────────────────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("PROMPT 3: CROSS-REFS + HYPHENATION")
print("=" * 60)

# Chapter cross-refs
text_all = '\n'.join(p.text for p in paras)
ch_headings = set()
for p in paras:
    m = re.match(r'(?:CHAPTER|Chapter)\s+(\d+)', p.text)
    if m and p.style and 'Heading' in (p.style.name or ''):
        ch_headings.add(m.group(1))
xrefs_all = set(re.findall(r'(?:Chapter|CHAPTER)\s+(\d+)', text_all))

# D3 Book 1 citation allow-list (from handoff lineage 685ed780, S48 deliverable):
# chapter references within ±100 chars of Book 1 markers are Wealth Operating
# System (Book 1) citations, not Book 2 cross-refs.
BOOK1_MARKERS = ['Wealth Operating System', 'Wealth OS', 'Book 1']

def is_book1_citation(text, match_obj):
    """Return True if the chapter reference at match_obj's position has a
    Book 1 marker within ±100 characters of context."""
    start = max(0, match_obj.start() - 100)
    end   = min(len(text), match_obj.end() + 100)
    window = text[start:end]
    return any(marker in window for marker in BOOK1_MARKERS)

# Identify which referenced chapters are *exclusively* Book 1 citations
book1_only = set()
for ch_str in xrefs_all - ch_headings:
    # Use negative-digit lookahead instead of \b so 'Chapter 21A' matches when ch_str='21'
    pattern = rf'(?:Chapter|CHAPTER)\s+{ch_str}(?!\d)'
    matches = list(re.finditer(pattern, text_all))
    if matches and all(is_book1_citation(text_all, m) for m in matches):
        book1_only.add(ch_str)

# "Next chapter is yours" idiom: reference to last_heading+1 inside metaphorical
# context (e.g., "Tumhari kahani is Chapter N+1") is authorial prose, not a
# broken cross-ref. Detect last_heading+1 with idiomatic markers.
IDIOM_MARKERS = ['tumhari', 'tumhara', 'your story', 'your chapter', 'kahani', 'shuru']
idiom_only = set()
if ch_headings:
    next_ch = str(max(int(c) for c in ch_headings) + 1)
    if next_ch in xrefs_all - ch_headings - book1_only:
        pattern = rf'(?:Chapter|CHAPTER)\s+{next_ch}(?!\d)'
        ms = list(re.finditer(pattern, text_all))
        if ms and all(
            any(mk.lower() in text_all[max(0, m.start()-200):min(len(text_all), m.end()+200)].lower()
                for mk in IDIOM_MARKERS)
            for m in ms
        ):
            idiom_only.add(next_ch)

broken = sorted((xrefs_all - ch_headings) - book1_only - idiom_only, key=lambda x: int(x))
book1_cited = sorted(book1_only, key=lambda x: int(x))
idiom_cited = sorted(idiom_only, key=lambda x: int(x))
print(f"  Chapters referenced: {sorted(xrefs_all, key=lambda x: int(x))}")
print(f"  Chapters with headings: {sorted(ch_headings, key=lambda x: int(x))}")
print(f"  Book 1 citations (suppressed from broken): {book1_cited if book1_cited else 'None'}")
print(f"  Idiomatic next-chapter refs (suppressed): {idiom_cited if idiom_cited else 'None'}")
print(f"  Broken cross-refs: {broken if broken else 'None'}")

# Hyphenation / spacing issues
lt_spaces = len(re.findall(r'[a-z]- [a-z]', text_all))  # broken hyphens
st_spaces = len(re.findall(r'  +', text_all))  # double spaces
print(f"  Broken hyphens: {lt_spaces}")
print(f"  Double-space runs: {st_spaces}")

# ─────────────────────────────────────────────────────────────────────
# PROMPT 4: STRUCTURAL DETECTORS — D1 (truncations) + D6 (duplicates)
# Ported v3.10.3 logic from Book 1 detector. v3.3 [S52 April 29 2026].
# ─────────────────────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("PROMPT 4: STRUCTURAL DETECTORS (D1 + D6)")
print("=" * 60)

# D1: Mid-word truncations
COMPLETE_SHORT = {
    'a','an','at','be','by','do','go','he','if','in','is','it','me','my',
    'no','of','on','or','so','to','up','us','we','as','am','via',
    'and','are','but','can','for','had','has','her','him','his','how','its',
    'may','new','not','now','off','old','one','our','out','own','see','she',
    'the','too','two','use','was','way','who','why','yes','you','any','all',
    'get','big','say'
}
TERMINAL_PUNCT = ('.', '!', '?', '"', ')', ']', ':', ';', '*', '%', '\u2014', '\u201D', '\u2019')
D1_TRUNC_WORDS = {
    'a','an','the','to','from','of','with','for','by','on','in','at','as','is',
    'and','or','but','into','onto','upon','than','that','this','these','those',
}
D1_STRICT_SENTENCE_END = ('.', '!', '?', '"', '\u201D', '\u2019')

d1_hits = []
for idx, p in enumerate(paras):
    t = p.text.rstrip()
    if not t or len(t) < 20:
        continue
    # Tertiary: EXACT-500-CHAR PIPELINE TRUNCATION (fires before early-skips
    # because pipeline truncation can land on em-dash / digit / colon).
    if len(p.text) == 500 and not t.endswith(D1_STRICT_SENTENCE_END):
        d1_hits.append((idx, 'TRUNC500', t[-50:]))
        continue
    if t.endswith(TERMINAL_PUNCT):
        continue
    if re.search(r'\d$', t):
        continue
    if len(t.split()) < 3 and t.isupper():
        continue
    m = re.search(r' ([a-z]{1,3})$', t)
    if m and m.group(1) not in COMPLETE_SHORT:
        d1_hits.append((idx, m.group(1), t[-50:]))
        continue
    m2 = re.search(r' ([a-z]+)$', t)
    if m2 and m2.group(1) in D1_TRUNC_WORDS:
        d1_hits.append((idx, m2.group(1), t[-50:]))

d1_status = 'PASS' if len(d1_hits) == 0 else 'FAIL'
print(f"  D1 Mid-word truncations: {len(d1_hits)} {d1_status}")
for idx, frag, tail in d1_hits[:10]:
    print(f"    [p{idx}] ends '...{frag}' \u2014 ...{tail}")
if len(d1_hits) > 10:
    print(f"    ... ({len(d1_hits) - 10} more)")

# D6-A: exact-text duplicates >=50 chars (Title/Subtitle excluded)
seen_texts = Counter()
text_first_idx = {}
for idx, p in enumerate(paras):
    if p.style and p.style.name in ('Title', 'Subtitle'):
        continue
    t = p.text.strip()
    if len(t) < 50:
        continue
    seen_texts[t] += 1
    if t not in text_first_idx:
        text_first_idx[t] = idx
d6a_hits = [(text_first_idx[t], count, t[:80]) for t, count in seen_texts.items() if count > 1]

# D6-C: heading-style paragraph followed by identical Body Text within 5 paragraphs
d6c_hits = []
for idx, p in enumerate(paras):
    if not (p.style and p.style.name.startswith('Heading')):
        continue
    t = p.text.strip()
    if len(t) < 10:
        continue
    for j in range(idx + 1, min(idx + 6, len(paras))):
        if paras[j].style and paras[j].style.name == 'Body Text' and paras[j].text.strip() == t:
            if not any(hit[0] == idx for hit in d6a_hits):
                d6c_hits.append((idx, j, len(t), t[:80]))
            break

total_d6 = len(d6a_hits) + len(d6c_hits)
d6_status = 'PASS' if total_d6 == 0 else 'WARN'
print(f"  D6 Duplicate substantive paragraphs: {total_d6} {d6_status}")
for idx, count, snippet in d6a_hits[:10]:
    print(f"    [p{idx}] appears {count}x: {snippet}...")
for h_idx, b_idx, length, snippet in d6c_hits[:10]:
    print(f"    [H1 p{h_idx} \u2192 BT p{b_idx}] (len={length}, H1+BT migration residue): {snippet}...")

# ─────────────────────────────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────────────────────────────
print("\n" + "=" * 60)
print("BOOK 2 SUMMARY")
print("=" * 60)
print(f"Word count total: {total_words:,}")
print(f"QC 22-point: {qc_pass}/{qc_total} PASS")
print(f"Chapters \u22654,500w: {chapter_wc_pass}/{len(chapters)}")
print(f"Cross-refs broken: {len(broken)}")
print(f"Character diversification: {diversity_status}")
print(f"D1 truncations: {len(d1_hits)} {d1_status}")
print(f"D6 duplicates: {total_d6} {d6_status}")
print(f"Tracked changes: {w_del + w_ins} (should be 0)")
print(f"SHA: {sha}")
