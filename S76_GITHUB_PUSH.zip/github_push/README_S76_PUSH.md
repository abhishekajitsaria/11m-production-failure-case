# S76 Session Push — May 6 2026

## Files in this push

### manuscripts/  (6 canonical editions)
- BOOK1_POST_v4_242.docx (SHA f2927e71) — 148,300 words, 3,995 paragraphs
- BOOK1_PRE_v4_143.docx (SHA 5547f26b) — 124,008 words, 3,783 paragraphs
- BOOK1_REWRITE_v4_184.docx (SHA 8cb65965) — 85,286 words, 1,963 paragraphs
- BOOK2_ENGLISH_v34.docx (SHA 794b2b4d) — 77,749 words, 2,327 paragraphs
- BOOK2_BILINGUAL_v26.docx (SHA 9d1d7bd0) — 79,847 words, 1,938 paragraphs
- BOOK2_HINGLISH_v22.docx (SHA 9846c8a7) — 76,380 words, 1,662 paragraphs

### process/  (governance + handoff state)
- WOS_CENTRAL_REGISTRY_v20_s52r5.xlsx (rows 1-178, S76 close + forensic correction)
- WOS_CLAUDE_SHORTCUTS_LOG_UPDATED_FINAL.md (S1-S444, includes S441 root-cause correction)
- 02_MANUSCRIPT_MAP.md (V11.6)
- WOS_SOP_v5_5.md
- 01_PROJECT_INSTRUCTIONS_PREAMBLE_v4.md
- S76_HANDOFF_PROMPT.md (S77 directive)

### scripts/  (verification + detectors)
- SESSION_START_VERIFY.py (NEW — mandatory session-start safety check)
- WOS_PROMPTS_v3_10_TEST.py (Book 1 detector)
- WOS_PROMPTS_BOOK2_TEST.py (Book 2 detector)

## S76 Summary

27 manuscript edits across 7 working turns + forensic root-cause investigation.

**Key change:** S441 SHA-blind-overwrite shortcut documented. Root cause corrected from "concurrent Opus instances" (initial wrong diagnosis) to "VM-cycle conversation pruning" (verified via process boot-time forensics). Three new defensive shortcuts added (S442/S443/S444), automated into SESSION_START_VERIFY.py.

## Push commands

From your local clone of the repo:

```bash
# 1. Place these files in your repo (preserve any existing structure)
cp -r manuscripts/* <your-repo>/manuscripts/
cp -r process/*     <your-repo>/process/
cp -r scripts/*     <your-repo>/scripts/

# 2. Stage + commit
cd <your-repo>
git add manuscripts/ process/ scripts/
git commit -m "S76 close: 27 manuscript edits + S441 forensic correction + SESSION_START_VERIFY.py

- POST v4_235 → v4_242 (D2/D3 structural moves, em-dash batch, Ch 28A NBFC stale-fix, Ch 33-34 orphan cleanup, R7 R3-propagation back-fill, p906/p2170 dup-deletion, R-rule counter consistency)
- PRE  v4_140 → v4_143 (Ch 28A propagation, Ch 33-34 orphan cleanup, trailing-ws)
- REW  v4_181 → v4_184 (E7 SEBI jargon def, F1 R13 Warehouse Risk Protocol naming, trailing-ws)
- ENG  v32 → v34 (D2 LIE #14 87-para move, p38/p40 dup-tail removal)
- BI   v25 → v26 (Lies #1/#2/#3 bilingual heading completions)
- HIN  v21 → v22 (D3 JHOOTH #14 77-para move)
- 0 tracked changes across all 27 edits
- All detectors PASS (REW D8=1 ISBN B2 carry-forward — only manuscript blocker)

S441 SHA-blind-overwrite root cause corrected to VM-cycle conversation pruning.
S442/S443/S444 defensive protocols persisted to shortcut log + automated in SESSION_START_VERIFY.py."

# 3. Push
git push origin main
```

## Important note re commit message

The commit message above is technical and factual. It does **not** reference the support dispute, chargeback, FTC complaint, or any framing about Anthropic's conduct. If your repo is public, that keeps the commit history focused on the manuscript work. Adjust if your repo has different conventions.
