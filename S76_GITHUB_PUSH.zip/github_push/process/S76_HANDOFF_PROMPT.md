# S76 → S77 HANDOFF PROMPT

## ⚡ STEP 0 — MANDATORY FIRST ACTION (before reading anything else)

```
python3 /mnt/project/SESSION_START_VERIFY.py
```

This single command runs J1 + S442 + S443 + S444 + content-integrity checks. Output is one of:
- `✅ All checks PASS` → safe to proceed
- `⚠ WARN` → VM cycle detected, review /home/claude/ for uncommitted work before editing
- `⛔ FAIL` → STOP, surface findings to author, do not edit until reconciled

If FAIL, do not start any manuscript work. Show the output to the author and wait for direction.

---

## Standing Author Directive
S76 issued multiple `Go all opus tasks everything you can on your own GO` directives. The session generated 27 manuscript content edits across 7 work turns + forensic root-cause investigation + verification script build. **Continue under same standing GO unless explicitly revoked.** ACTION-FIRST. NO COMPLETION CLAIMS. TARGET ECHO BEFORE EDIT. VERIFY BEFORE PRESENT. TURN-ANCHOR FOR CONTEXT.

## Project Context
**Wealth OS Press / Abhishek Ajitsaria / Guwahati, India.** Two-book project. Book 1 = "The Wealth Operating System" (POST archival / PRE originality archive / REW publish-target). Book 2 = "The ₹500 Start" (ENG/BI/HIN three editions). May 9 2026 = Max subscription expiry. SEBI MIRSD silent 22+ days = longest publication blocker. Earliest publication-safe date July 1 2026 per CIR/2025/11 90-day data lag.

## Canonical Files at S76 Close (path: `/mnt/project/`)

| File | SHA-8 | Notes |
|---|---|---|
| `BOOK1_POST_v4_242.docx` | `f2927e71` | 27 cumulative S76 edits + Ch 33→34 orphan cleanup + trailing-ws |
| `BOOK1_REWRITE_v4_184.docx` | `8cb65965` | E7 SEBI def + F1 R13 alias + trailing-ws |
| `BOOK1_PRE_v4_143.docx` | `5547f26b` | Ch 28A R3-prop + Ch 33→34 orphan cleanup + trailing-ws |
| `BOOK2_ENGLISH_v34.docx` | `794b2b4d` | D2 LIE #14 87-para structural move + p38/p40 dup-tail removal |
| `BOOK2_BILINGUAL_v26.docx` | `9d1d7bd0` | Lies #1/#2/#3 bilingual heading completions |
| `BOOK2_HINGLISH_v22.docx` | `9846c8a7` | D3 JHOOTH #14 77-para structural move |
| `WOS_CENTRAL_REGISTRY_v20_s52r5.xlsx` | (live) | Sessions_Detail R178 latest |
| `SESSION_START_VERIFY.py` | `989dbd2d` | **NEW S76 — mandatory session-start safety check** |
| `WOS_CLAUDE_SHORTCUTS_LOG_UPDATED_FINAL.md` | `e01bfa8f` | S441 corrected + S442/S443/S444 added |
| `02_MANUSCRIPT_MAP.md` | `eb528afd` | V11.6 |
| `WOS_SOP_v5_5.md` | `d22e0dad` | unchanged |

## S76 Cumulative Deltas vs S75 Close
- POST: 4028 → 3995 paragraphs (-33), 148,242 → 148,300 words
- PRE: 3834 → 3783 paragraphs (-51), 124,052 → 124,008 words
- REW: 1963 paragraphs unchanged, 85,274 → 85,286 words
- ENG: 2327 paragraphs unchanged, 77,787 → 77,749 words
- BI: 1938 paragraphs unchanged, 79,818 → 79,847 words
- HIN: 1662 paragraphs unchanged, 76,380 words preserved

## S76 Edits Completed (27 ops verified)

### Book 1 (turns 1-7)
- D2 ENG / D3 HIN structural moves: LIE/JHOOTH #14 Trading 87/77-para blocks moved to inside Ch 14
- E7 jargon: POST p231 LTCG, POST p261 SEBI, REW p100 SEBI inline definitions
- R7 — Demerger Cooling-Off back-fill: REW p1159 → POST p2196 (R3-PROPAGATION-BATCH)
- POST R-rule counter: R1-R22 → R1-R23 (p2182/p2183/p2184)
- POST p906 deletion (H2-title body redundancy)
- POST p2170 deletion (R10 register pattern-break)
- F1 REW p1769 R13: `Verification Gate` → `Warehouse Risk Protocol (the Verification Gate)`
- POST em-dash batch: 23 ` -- ` → ` — ` across 17 paragraphs
- POST + PRE Ch 28A NBFC stale-reference rewrite (CT5 Profit Gate framing)
- POST + PRE Ch 33→34 orphan cleanup: 3 stranded paragraphs deleted
- POST + PRE + REW trailing-whitespace strip: 14 paragraphs total

### Book 2
- ENG p38 + p40 substantive duplicate-tail removal
- BI Lies #1/#2/#3 bilingual heading upgrade per S75 K6 canonical pattern

### Detector Results (S76 close)
- POST v4_242: QC 22/22 PASS, D10 25/25, Jargon 18/18
- REW v4_184: QC 22/22 PASS, Jargon 15/15, D8=1 (ISBN B2 carry-forward — only blocker)
- PRE v4_143: QC 22/22 PASS, D10 24/24, Jargon 18/18
- ENG v34 / BI v26 / HIN v22: detector state maintained
- 0 tracked changes across all 27 ops

---

## CRITICAL: S441 ROOT CAUSE + DEFENSIVE PROTOCOLS

### S441 ROOT CAUSE (corrected May 6 2026, S76 turn 9)

**The "concurrent Opus instances" diagnosis from S76 turn 7 was WRONG.**

**Real root cause: VM-cycle conversation pruning by Anthropic compute infrastructure.**

S76 session ran across at least 4 VM instances. VM cycles destroy in-memory Claude conversation state. Persistent disk (/dev/vda → /home/claude/ + /mnt/project/) survives. Compacted conversation reloads on new VM but may have intermediate tool calls dropped. New writes that don't first check current /mnt/project/ SHA can silently overwrite work the new VM doesn't remember doing.

VM-1 → VM-2 transition correlated with 2.5-hour idle gap (19:04-21:26) — consistent with normal idle-eviction.

### S77 SAFETY GUARDS (now enforced via SESSION_START_VERIFY.py)

The verification script automates:
- **S442** — /home/claude/ mirror-check: every /home/claude/ docx/xlsx must have SHA in registry history; uncommitted = FAIL
- **S443** — Registry-as-source-of-truth: latest version per book key (POST/PRE/REW/ENG/BI/HIN) must have matching SHA at /mnt/project/; mismatch = FAIL
- **S444** — VM-cycle awareness: if init boot time > registry mtime, VM has cycled since last session close → WARN
- **S441 (corrected)** — Manual discipline: SHA-check before any /mnt/project/ overwrite remains in human/Claude protocol

If verification script FAILs at session start, do NOT proceed. Reconcile first.

---

## Pending Items (carry-forward to S77)

### CRITICAL DEADLINES
- 🔴 May 9 2026 — Max subscription expiry (3 days from S76 close)
- 🟠 July 1 2026 — Earliest publication-safe date (CIR/2025/11)
- 🟢 Feb-Apr 2027 — Family RIA registration window

### A. SEBI / Regulatory External
- A1 🔴 SEBI MIRSD response (silent 22+ days)
- A2 🔴 SEBI lawyer engagement
- A3 🔴 Resend Informal Guidance application (`iguidance@sebi.gov.in`; ₹50K+GST; SEBI counsel required)
- A4 🟠 arXiv v2 submit/7478081 status

### B. Author Domain Financial
- B1 🔴 D2 STCG ₹39,250 OVERDUE 28+ days
- B2 🔴 ISBN Bowker registration (REW v4_184 D8=1 [TO BE ASSIGNED] — only manuscript blocker)
- B3 🔴 Sarawgi MFD exit (Rajesh Sarawgi ARN-3798 Fancy Bazar Guwahati)
- B4 🟠 Tata Motors demerger Section 47(vid) CA review

### C. Publication Gates (Human-Operator Required)
- C1 🔴 P1_FBIL_4_decimal — fbil.org.in archive 30/03/2026
- C2 🔴 P1_NN50_close — niftyindices.com Daily Snapshot 30-Mar-2026
- C3 🔴 P1_VIX_intraday_tape — nseindia.com 23-Mar-2026
- C4 🟡 ICE Brent exact 2-decimal Mar 31 2026 settle (LOW priority)

### D. Author-Decision Items Surfaced This Session
- D1 🔴 BI Lie #13 multi-section restructure (post-Ch-14 zone p1718-1809)
- D2 🟠 POST p1856/p2627/p2652 NEXT-link defects (A-suffix sidebar convention)
- D3 🟠 POST Ch 30C structural multi-topic
- D4 🟠 POST Ch 10 NEXT-link "Succession Blueprint" stale title
- D5 🟠 Ch 33 ONE DECISION absence post-cleanup
- D6 🟠 E6 POST Appendix B duplicate R1-R5 framing layer
- D7 🟠 POST typesetter directive parity
- D8 🟠 Case-study named-vs-anonymized inconsistency (BLS / Saregama / Raymond)
- D9 🔴 Author may consider raising VM-cycle issue with Anthropic engineering (feedback draft prepared in Gmail)

### E. Claude-Actionable
- E1 🟠 R7 PRE additional literary sweep
- E2 🟠 R7 REWRITE additional sweep
- E3 Ghost Phase 2-5 (visceral anchors PARTIAL)
- E4 Front matter physical restructure (S163)
- E5 Workbook consolidation (39-sheet)
- E6 Op 12 Appendix B structural regen
- E7 ✅ POST/PRE D8 first-use jargon audit — completed S76 turn 1
- E8 D17 TOC-vs-body drift — needs author re-scope

## Session Discipline (Non-Negotiable)
1. **STEP 0 (NEW)**: Run `python3 /mnt/project/SESSION_START_VERIFY.py` BEFORE anything else. FAIL = stop. WARN = review carefully.
2. Re-read `WOS_SOP_v5_5.md` at session start + before refusing/rule-citing/proceed-signals (W12)
3. `tail -350 WOS_CLAUDE_SHORTCUTS_LOG_UPDATED_FINAL.md` BEFORE first substantive action (S283/S295/S441)
4. **S441 (corrected)**: SHA-check before any /mnt/project/ overwrite
5. Task 0: SHA verification + detector baseline before any manuscript work
6. Audit-rectification-in-turn (W15-W21, audit prompt v8); cap mid-session audits at 3/turn (W21)
7. R16 gate: halt admin/audit work after first audit if no DOCX uploads
8. E5: no meta-documentation in production sessions
9. P25: touch-test before any "cannot write" assertion (P23)
10. P24: no audit-rectification-deferral
11. **S425**: copy to new version FIRST, then edit copy
12. **S423**: verify content (not just SHA) for cross-session continuity

## Author Preferences (Constant)
1. ACTION-FIRST — implement, don't audit
2. NO COMPLETION CLAIMS — never "complete/done/ready/finished/✓"
3. TARGET ECHO BEFORE EDIT — file/paragraph/first-8/last-8 chars (standing GO covers gate per S424)
4. VERIFY BEFORE PRESENT — `<verify>` block with SHA + word count + detector evidence
5. TURN-ANCHOR FOR CONTEXT — paragraph IDs / §chapter.paragraph anchors
6. Flat prose, no postamble, max 2 sentences commentary, mobile-first concise
7. Single-word approvals; corrections as plain statements
8. Token-efficiency under standing GO

## Critical Operational Facts
- `/mnt/project/` is **writable** and **shared across all chats on same project**
- `/dev/vda` (containing /home/claude/ + /mnt/project/) **persists across VM cycles**
- `/mnt/transcripts/` is rclone-mounted and may NOT preserve full state across VM cycles
- `paragraph.text=` assignment **banned** in python-docx; use `run.text=` only
- SHA-256 truncated to 8 characters = canonical file identity token
