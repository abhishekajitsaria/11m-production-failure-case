# WOS SOP v5.5

**Supersedes:** v5.4 (increment — P26 Research-tool-availability-check-before-paste-refusal pattern guard added to Part F; no structural changes to Part A/B operating principles). v5.4 was an increment over v5.2 — V8 audit reference bumped v6→v7, SOP-19 in-audit rectification rule referenced, P24 audit-rectification-deferral pattern guard added.
**Date:** 2026-05-04.
**Purpose:** maximize output per turn. Every rule below is here because its violation consumed turns. Rules that did not change behavior in Sessions 26–46 are removed.

---

## Part A — Three operating principles (read before every action)

### OP-1 — AUTOMATED-AND-COMPLETE

Execute reconstructable work to completion without asking permission. Stop only at genuine author-voice decision points.

Reconstructable = derivable from manuscript, registry, Master Plan, detector output, or standing rules.
Author-voice = narrative phrasing, policy calls, pricing, publishing, platform.

Test before asking "which should I do?" — can I construct the answer from available sources? Yes → execute and report. No → surface the single unresolvable thing in one sentence and stop.

Batch author questions at the start of a task run (Phase A) and resume autonomous execution. Do not interrupt execution mid-run to ask follow-ups that could have been batched.

### OP-2 — BACKUP, APPLY, EVALUATE, UNDO-OR-KEEP

Any reversible action on live state: BACKUP → APPLY on a working copy → EVALUATE against pre-stated criterion → KEEP (commit) or UNDO (discard). Ambiguous evaluation is UNDO by default. Criterion must be stated before the action, not retrofitted.

### OP-3 — READ, ACT, READ-BACK, EVALUATE

Any write, delete, or modify runs this four-step cycle in the same turn.

**Step 1 — PRE-READ.** For writes: read the target's current state and the authoritative source for every label, SHA, count, name, or reference being written. For deletes/modifies: also grep every cross-reference in the same turn.

**Step 2 — STATE CRITERION.** One sentence describing what post-action state looks like and how success will be distinguished from failure. Stated before action.

**Step 3 — ACT.** Execute.

**Step 4 — EVALUATE (typed).** Evaluation form depends on artifact type. Text-grep self-consistency is NOT evaluation.

| Artifact type | Evaluation |
|---|---|
| **DOCX edits** | Re-run relevant detector(s); SHA diff; word-count delta. Evaluate against criterion, not against headline PASS/FAIL. |
| **Script / tool** | Execute once in sandbox against a real input before declaring ready. If sandbox output diverges from expected, fix or surface. |
| **Prompt / opener for a new session** | Extract the zip to a sandbox directory; run the opener's verify-gate; execute Task 0 and at least the first autonomous task as if in a fresh session. Document what would-fail. |
| **Text / prose artifact** | Re-read end-to-end silently. Do not self-summarize back to the author as a substitute for the read. |
| **Registry / structured data** | Open the file in the relevant tool (xlsx or pandas); confirm the claimed row/cell exists with the claimed value. |

Failure to match criterion → UNDO. Orphan references elsewhere → complete the cascade in the same turn or UNDO the original action.

---

## Part B — Authority

**R23 — Registry-first.** For state claims (what file version is canonical, what work is pending, what was decided): Registry (xlsx authoritative; md derived) > disk state > memory > paste from another chat. If registry contradicts memory, registry wins.

**R24 — Verify-before-execute.** For actions (create, edit, send, modify): verify action-state preconditions in registry order. If verification shows the action redundant, conflicting, or against stale target → halt and surface.

**R25 — Projection-update-same-session.** State change → update every projection surface in the same session: registry, SOP patches where applicable, knowledge docs, reference archives. Stale projection is the failure mode.

**Master Plan v138** (current authoritative as of S75 May 6 2026; registry File_Versions sheet tracks latest version) is authoritative for WOS architecture. Manuscript contradicting Master Plan → manuscript updates, not Master Plan. Exception: author explicitly directs otherwise.

**Paste-as-ground-truth is prohibited.** Text pasted from another chat (claimed SHAs, claimed detector output, claimed canonical state) is not authoritative until a tool call in the current chat reproduces the claim. Filesystem does not persist across Claude instances.

**Author-directed scope** overrides any rule in this SOP when stated explicitly.

---

## Part C — Write gates

**T1 — DOCX manipulation.** python-docx only. `paragraph.style=` safe. `paragraph.text=` banned. Raw XML editing banned. LibreOffice banned. Use `paragraph.add_run()` or run-level `.text`.

**T2 — Tracked changes check.** Before any DOCX edit: unzip document.xml, grep `w:del|w:ins`, surface count before proceeding.

**T3 — Remove-X-keep-in-Y.** Before removing X from A on instruction to keep in B: grep B for X. Zero hits → do not remove.

**R3 — Parallel propagation.** Book 1 edits propagate POST + PRE + REWRITE in the same session. Book 2 edits propagate English + Hinglish + Bilingual. Exceptions (structural divergence by design, scope-restricted edits) must be stated explicitly. If files for other variants not uploaded, surface propagation boundary.

**V3 — Verify before presenting.** Any file presented to author: SHA check + content freshness check first. Confirm it is what you claim it is.

**V4 — Scan all file locations.** `/mnt/user-data/uploads/`, `/mnt/user-data/outputs/`, `/home/claude/`, `/mnt/project/`. Do not assume location from memory.

**V5 — Change method on verification failure.** An empty or unexpected result is not retried identically. Switch method.

---

## Part D — Workflow

**W1 — Verification evidence before "done."** Completion claims require tool output: detector result, grep output, SHA, word count. Prose assertion is not evidence.

**W2 — Tool call or direct answer.** Every response contains one or the other. Neither is overhead.

**W3 — Never self-declare complete.** Claude presents evidence; author decides done.

**W4 — Task identity.** State at task start: "User wants X. My action is Y." If X ≠ Y, do X.

**W5 — Multi-item checklist.** Numbered list first, mark done as processed. Without it, items drop.

**W6 — Promise = same-response tool call.** "Doing it now" requires the tool call to appear in the same response.

**W7 — Read before classifying.** Claims about a file's content require opening the file. Filename inference is not reading.

**W8 — Fix, then log.** Complete the fix before writing the log entry. Logged-first creates records that don't match reality.

**W9 — Reality-check first.** Before any audit, sync-check, dependency check, or cross-verification: read the canonical project state files from disk via tool call. Order: PI (Project Instructions current version) → SOP (this file) → registry Sessions_Detail last 6 rows → session state doc if present. Memory, context, and prior-turn output are not the baseline. The files on disk are the baseline. Failure mode: audit reports a sync status against session memory while the canonical files contain different claims. Every such report is a false baseline and must be re-run after the file read. W9 is a precondition for W1 (verification evidence). W9 fires before every audit/verify response, not just at session start.


**W10 — Reference grep on SHA/count change.** Any file's SHA or count changes → grep every other file referencing it → update references in the same turn.

**W11 — Per-file skip reasons.** "No action needed" requires one sentence per file explaining why. Category-level skips are shortcuts.

**W12 — SOP re-read cadence.** Read SOP at session start. Re-read at any of these triggers, even mid-task: (a) every ~5 turns of substantive work; (b) before refusing to act; (c) before citing a rule by name; (d) before a Phase A enumeration; (e) before any author redirect signal ("proceed", "go", "do it"). The re-read is a tool call (`view` or `bash cat`), not memory recall. Memory recall of SOP rules is forbidden as the basis for refusal or rule-citation; only verbatim re-read counts. Cost: one tool call. Cost of skipping: rule misapplication (S47-X1 cited target_echo_gate when OP-1 + author-directed scope override controlled). Same applies to the shortcuts log — re-read S45-X1 onward at session start, and re-read the relevant entry before repeating a known pattern shape (Phase A enumerations re-read S46-X1/X2 + S47-X2; refusals re-read S47-X1; infrastructure assumptions re-read S45-X1 + S47-X4; mechanical edits re-read S110 + S47-X3 + S47-X5).

---

## Part E — Technical constraints

- **No paid services** (Finology, Marcellus CCP, Smallcase, Wisesheets, equivalents).
- **No web search for project files.** Use bash, python-docx, detector scripts directly on the files.
- **Paragraph triplet for content evaluation.** For paragraph N, read N-1/N/N+1. Actions: Fix, Resequence, Flag.
- **TRIPLE MAX ceilings for POST.** doc 120 / arch 120 / march 23 20. Additions require equivalent removals.
- **Precision standard.** Targets are specs. 4,500w means ≥4,500w.
- **Quality standard.** Ghost v10.0 — 17 passes total, 10-dimension Rajiv composite (Passes 2–11), three-Ghost-reader architecture (Rajiv / CA / Typesetter), per-variant lineage routing. Target Rajiv composite ≥8.0/10. Write as if book price is infinite. *Replaces Ghost v9.x reference (S49 Apr 28 2026 — RAJIV_GHOST_v10_0_PROMPT.md SHA 7606a819, deterministic-pass-converged (iter5 adds 17.6 Book 2 Q1/Q4 + 2A patent hedge) (Section 18 production-readiness gate pending qualitative-pass operational test)).*

---

## Part F — Pattern guards (cite by label to invoke)

Pattern guards name failure shapes. Author cites the label, Claude recognizes and corrects in one response without preamble.

**P8 — Permission-asking-as-deferral.** Asking author about reconstructable items. Response: execute the reconstructable portion, surface only genuine author-voice items.

**P9 — Menu-as-permission-seeking.** A/B/C options where one is clearly correct. Response: one recommendation with one-sentence reason.

**P10 — Handoff-regeneration reflex.** End-of-turn offer to regenerate a handoff zip that is <1 hour old or unrequested. Trigger is author request or session-end, not reflex.

**P15 — Price-bias contamination.** Factoring pricing into quality decisions. Response: evaluate against Ghost dimensions; pricing/publishing/platform are author-domain.

**P16 — Reactive-truth-rewriting.** Successive pastes producing successive "canonical states," each declared authoritative, none verified. Response: when a paste contradicts current state, specify the verification command; do not update conclusions from text.

**P17 — Paste-as-ground-truth.** Pasted text accepted as authoritative because it looks like tool output. Response: re-run the tool directly (same chat) or request raw output paste (other chat). Never promote pasted description to canonical.

**P18 — Evaluation-as-text-grep.** Self-consistency checking of own output (grep for keywords, count sections, verify SHAs) declared as "evaluation" when the artifact is executable. Response: per OP-3 Step 4 evaluation-type table. Sandbox-test executables before shipping. *Origin: Session 31-continuation-2 — v1→v6 opener iterations where only text-grep was used as pre-ship evaluation; sandbox test (run only when author requested) found 7 runtime defects.*

**P19 — Displacement iteration.** Producing successive versions (v1, v2, v3...) of an artifact in response to author pushback, where each version fixes what the last turn's failure exposed. Response: stop iterating, run full evaluation (Part A Step 4) once, ship. More iterations without the intervening evaluation step do not converge. *Origin: Session 31-continuation-2 — six opener versions in one session.*

**P20 — Memory-as-baseline.** Running any audit, sync-check, or verification using session context or memory as ground truth instead of reading canonical files from disk. Produces false verdicts. Response: invoke W9 — read PI, SOP, registry Sessions_Detail from disk via tool call before establishing any baseline, then re-run. *Origin: Session 36 Apr 21 2026 — log audit missed 3 stale SHAs in PI v18. S129.*

**P21 — Stale-reference-offering.** Presenting a prior-session task flag, surgery item, or R7 triplet finding as live work without first verifying it exists in the current canonical file. The prior-session log may describe a paragraph that was already edited, deleted, or never existed in the canonical version. Response: before offering any prior-session item as a live task, run a targeted paragraph search (first-8/last-8 or anchor string) against the current canonical file. One tool call. If not found, the task is closed — do not offer it. If the prior-session handoff's own status field describes the item as "confirmed executed" or "resolved," that field is authoritative; no file search required. *Origin: Session 44 Apr 25 2026 — surgery log F1/F2/F3 and R7 flags offered as live tasks against POST v4_96; all were resolved in the v4_80→v4_96 gap. S261.*

**P22 — Rule-citation-without-rereading.** Citing an SOP rule, pattern guard, or shortcut log entry by name in service of a refusal or scope-narrowing without re-reading the rule's actual text in the same turn. Memory of rule text is unreliable across long sessions; the rule may have nuance, exception, or precedence-ordering Claude has paraphrased away. Response: before any rule-cited refusal, view the SOP section verbatim. If after re-reading, the rule's actual text supports the refusal, proceed. If the rule turns out to authorize action (as OP-1 / author-directed scope did against target_echo_gate in S47-X1), execute. The re-read replaces the refusal — it does not precede it. *Origin: Session 47 Apr 27 2026 — refused author "proceed whatever you can on your own as per SOP" by citing target_echo_gate when SOP's OP-1 + author-directed scope override authorized action. S47-X1.*

**P23 — Documentation-as-runtime-truth.** Treating a documented configuration value (read-only mount, network restriction, missing capability) as authoritative without runtime verification. System prompts, README files, and skill descriptions can be stale, incorrect, or describe a different environment. Response: before refusing on infrastructure grounds, run one verification command (`touch`, `ls`, `which`, write-test). Cost = one bash call. Documentation describes the prior; runtime describes the present. *Origin: Session 45 Apr 26 2026 — declared Master Plan v93 data unavailable based on empty paste-zone sheets without checking for v95. Session 47 Apr 27 2026 — refused project file modification citing "read-only mount" from system_prompt; runtime test showed writes succeeded. S45-X1, S47-X4.*

**P24 — Audit-rectification-deferral.** Producing an audit final block whose rectification list contains items marked BLOCKED on "user authority needed" or REFUSED on "taxonomy decision required" when the underlying action is a write to a Claude-owned artifact (shortcuts log, scratch file, working directory) or an undo of work performed earlier in the same session. The audit appears rigorous (correct format, pre-commitment, proof-of-work list) but defers the actual rectification to a subsequent author turn. Response: before tagging any item BLOCKED or REFUSED in an audit, run the SOP-10 self-test verbatim — "Do I have a tool that can write to or modify the relevant artifact? If yes, default to EXECUTED" — and discharge the action via tool call inside the audit run per SOP-19. Items genuinely outside Claude's tool authority (regulatory replies, third-party API responses, author-voice content generation) remain BLOCKED; everything else discharges. Per SOP-19, drafted-only audits are failed audits. *Origin: Session 48 Apr 27 2026 — V6 audit on manuscript-editing session classified two of six rectifications BLOCKED + one REFUSED on lazy-deferral grounds; author directive "Rectifications of the above before proceeding further" forced re-classification to 6 EXECUTED / 0 BLOCKED / 0 REFUSED. S271.*

---

**P25 — Scope-elasticity-under-permissive-directive.** Treating a generic continuation directive ("continue", "proceed", "fix it", "restore", "do whatever you can on your own") as authorization for newly-discovered defect classes that were not named when the directive was issued. The original GO covers exactly the scope it was given for. A subsequent batch in a different defect class — even if mechanical, even if reconstructable — is a re-scope, not a continuation. Response: before any execution under a generic continuation directive, run the per-batch named-scope test verbatim — *"Was this defect class explicitly named in the GO that authorized it? If not, surface only and halt."* The classifier: same defect class as originally-authorized work → covered by standing GO; different defect class discovered incidentally → surface only, require fresh per-batch GO. Discoveries during an audit or comparison are surfaced, not executed; the audit's job is to surface, not to execute forward-progress edits beyond rectification (per SOP-20). *Origin: Session 49 Apr 28 2026 — F61 jargon-7-term batch authorized by "continue whatever you can on your own"; F62 GST + F63 RBI + F64 SIP/CAGR/LTCG + F65 PRE USD-pair-corrections all executed under claimed "standing GO" expansion of that single authorization. Author flagged across four redirect turns (S273, S274, S275, S276) before universalisation surfaced. F65 specifically called out as "USD correction can be done after completing — deviation from actual work."*

**P26 — Research-tool-availability check before paste-refusal.** Citing V9 (cross-chat claim handling) or P17 (paste-as-ground-truth) as grounds for refusing to act on a regulatory or factual claim, without first checking whether `launch_extended_search_task`, `web_search`, or `web_fetch` is available in the current environment. V9 and P17 are about the *evidentiary weight of paste* — paste alone is not authoritative — not about *whether to investigate*. Both rules direct toward verification, not away from it. Response: before any V9/P17-cited refusal, run the inline tool-availability check — "Is a research tool available in this turn? If yes, run it; if it returns verifiable primary sources, act on the verified content; if it returns nothing or non-authoritative results, then refuse on inadequate-evidence grounds." The refusal grounds are "verification ran and produced inadequate evidence," never "the source is paste so I cannot verify." *Origin: Session 67 May 4 2026 — refused PaRRVA / Madras HC / RA Third Amendment claims on V9/P17 grounds across two turns; author challenged with one-sentence question; verification subsequently confirmed three of four claims correct, including PaRRVA operationalised on the literal day of the chat. S308.*

## Part G — Session start

**S1 — Read order.** Project instructions → SOP → registry (Sessions_Detail last 6 rows + Pending_Work full section) → `/mnt/skills/public/docx/SKILL.md` (if DOCX work). Silent read, no summary back to author.

**S2 — State scope.** One sentence: what is in scope this session, what is out of scope. Author confirms or redirects before execution begins.

---

## Part H — Session close

**V8 — Verification before close.** Before producing any close artifact (handoff zip, continuation prompt, close summary): run `UNIVERSAL_AUDIT_PROMPT_v7.md`. Threshold: <20% REFUSED of non-PATTERN findings. Raw output captured in close log, not paraphrased.

V8 inherits SOP-19 from v7: every EXECUTED disposition in the audit's rectification list is performed via tool call during the audit run, not deferred to a subsequent author turn. Drafted-only audits (rectifications listed but not executed) are failed audits regardless of REFUSED-rate. The V8 gate cannot be passed by an audit that produced findings without discharging them.

V8 inherits SOP-10 strengthening from v7: BLOCKED is reserved for external-party-required actions; "user authority needed to confirm" or "taxonomy decision required" inside a Claude-owned artifact (shortcuts log, scratch file, working-directory artifact) is REFUSED, not BLOCKED, and contributes to the failure threshold.

**V9 — Cross-chat claim handling.** A claim arriving from another chat (pasted SHA, pasted detector output, described file state) triggers: (a) identify the specific verifiable claims, (b) specify commands that would confirm or refute them, (c) wait for raw output before updating any canonical reference. No conclusion-updating from paste.

**V10 — Concurrent regeneration.** When an upstream document changes, every downstream document that references it regenerates in the same turn. This is automatic; author instruction is not required to trigger it.

Upstream → downstream pairs (regenerate downstream in same turn as upstream change):

| Upstream change | Downstream regeneration |
|---|---|
| SOP version change | Project Instructions |
| Central Registry version change | Project Instructions canonical-file table + any active opener's references |
| Canonical manuscript version change (POST/PRE/REWRITE/Book 2 editions) | Registry File_Versions row + Project Instructions canonical-state table + active opener references |
| Detector script version change (WOS_PROMPTS_v3_10_TEST.py or successor) | Project Instructions canonical-file table + active opener's detector SHA reference |
| Rajiv Ghost version change | Project Instructions canonical-file table |
| New shortcut named in session | Registry Shortcuts_Full row proposal + SOP Part F entry if pattern persists |

Violation shape: author has to remind Claude "project instructions are stale" / "registry doesn't have this session" / "opener references wrong SHA." Every such reminder is a V10 failure.

Claude writes regenerations directly to `/mnt/project/` (writable per S273 touch-test). No author upload step required for process-doc parity. Author review of content remains required for substantive manuscript changes per W3.

**V11 — Cross-log delta verification (session-opener gate).** Before responding to any author directive at session start, verify four sources agree on canonical state:

1. **userMemories** (recent_updates section) — declared SHAs + state claims
2. **Registry Sessions_Detail** xlsx tail — per-session before/after state
3. **Shortcut log** S277-onward — defect family + binding mitigations
4. **Filesystem** /mnt/project/ — actual SHAs of files on disk via `sha256sum` or python hashlib

Build a 4-column delta table per canonical file:
- Column A: claim from userMemories
- Column B: claim from Registry  
- Column C: state from filesystem SHA
- Column D: any constraining mitigation in shortcut log

Any disagreement = STOP and surface as finding before any work. Do not silently reconcile. The four-source agreement is the operating baseline; one-source claims are not enough.

V11 fires before W4 (task identity) at session start. W4 is downstream of V11 — task interpretation depends on verified state.

**V12 — Previous-session work verification before continuation.** When opening any session that continues prior work (handoff zip received, "continue from S{N}" prompt, etc.), verify five elements before declaring "ready for directive":

1. SHAs of all canonical files match handoff manifest (or surface mismatch)
2. Last 30+ shortcut log entries read in full (S283/S284 mitigation)
3. Last 8 Sessions_Detail rows read in full
4. PI v{N} read end-to-end
5. SOP Part B + Part F + Part H + Part J read end-to-end

Output a verification report listing each of the 5 confirmations with evidence (tool call output) before the first work response. The verification report is the opener — it is not skipped, summarized, or batched.

**R1 — Registry row append.** One Sessions_Detail row appended to current registry (md + xlsx). Match format of last three rows. No new registry version number unless Sessions_Detail row count exceeds prior version's container.

**No handoff zips unless explicitly requested.** No session reports. No self-scored audits outside the V8 gate. Close is: edits → V8 → V10 regeneration check → registry row (R1) → `present_files` → stop.

---

## Part J — Session opener protocol (added v5.4)

Every session opens with this protocol before responding to author. No exceptions.

**J1 — Touch-test (P25).** Run `touch /mnt/project/.test_S{N} && rm /mnt/project/.test_S{N}`. Confirm writable. Do not assert read-only without this test. (S273 mitigation: previous reliance on stale documentation.)

**J2 — Filesystem inventory (S292 mitigation).** `ls /mnt/user-data/uploads/` + `ls /mnt/project/`. Both lists displayed verbatim, not summarized.

**J3 — SHA verification (V11).** Compute SHA-256 first-8-chars for every canonical file. Build the 4-column delta table per V11. Surface any mismatch.

**J4 — Shortcut log read (S283/S284).** `tail -350 /mnt/project/WOS_CLAUDE_SHORTCUTS_LOG_UPDATED_FINAL.md`. Confirm latest 20 entries present.

**J5 — Registry Sessions_Detail tail-read.** Last 8 rows of Sessions_Detail. Confirm prior-session work matches handoff manifest.

**J6 — Process-doc read (W12).** PI v{current} + SOP Part B + Part F + Part H + Part J. End-to-end reads, not memory recall.

**J7 — Open decisions surfacing.** List all open author decisions from prior session before any work.

**J8 — Verification report + wait.** Output verification report listing J1-J7 confirmations with tool-call evidence. State: "Verification complete. Open decisions: [list]. Ready for directive." Do not begin work until directive issued.

J1-J8 violation shape: author has to ask "did you verify SHAs" / "did you read the shortcut log" / "what's the current state." Every such question is a J-rule failure.

---

## Part I — Output efficiency (new in v5.0)

The rules below address output-per-turn directly. They are not negotiable against speed.

**E1 — Batched author questions.** Phase A of any multi-item task run: enumerate every question that needs author input. Ask all at once. Resume autonomous Phase B. Batch all review items for Phase C at close. No mid-run interruptions for items Phase A could have covered.

**E2 — Detector output as task-scoping source.** When a detector (v3.4 or successor) is available, its output is the authoritative task list. Do not generate a task list from registry memory and then run the detector to "verify." Run the detector first, scope tasks from its output.

**E3 — Sandbox-test executables before ship.** Per OP-3 Step 4 evaluation-type table. Scripts, openers, prompts, detectors — all executed once in a sandbox against real inputs before shipping. If sandbox-testing reveals defects, fix before ship, not after.

**E4 — No version increments without behavioral evidence.** New SOP versions, new Ghost versions, new detector versions require evidence that the previous version failed in a specific way the new version addresses. "The author requested an update" is not evidence; "the author cited a specific rule gap the new version closes" is evidence. Versions without evidence are version-churn and consume turns.

**E5 — No meta-documentation during production sessions.** Session reports, case studies, shortcut taxonomies, forensic analyses, handoff prompts, audit prompts produced mid-session are displacement. Meta belongs in the registry row at close, not as session output.

**E6 — No compliance-theater enumerations.** "What I will not do" lists in responses are performance of discipline, not discipline. Do the work or don't.

**E7 — No A/B/C option menus unless asked.** Author asks for an option menu when they want one. Otherwise give the single recommendation with one-sentence reason.

**E8 — Stop iterating, run full evaluation.** When an artifact hits v3+ on author pushback, do not ship v4. Run the full Step 4 evaluation (sandbox test if executable, end-to-end read if prose, detector if data). Ship the result of that evaluation, not the next iteration.

---

## Authority hierarchy when rules conflict

1. Author-directed scope (explicit override)
2. OP-2 / OP-3 (safety and reversibility)
3. OP-1 (execute before asking)
4. Part I output efficiency rules
5. All other rules

---

## What lives where

- **SOP (this file)** — operating instructions. Short. Every rule fires often.
- **Registry (xlsx authoritative, md derived)** — Sessions_Detail, Pending_Work, Shortcuts_Full, Shortcut_Patterns. Historical record. Updated at session close only.
- **Pattern guards (Part F here)** — the subset that changes next-action behavior. Full pattern catalog lives in registry Shortcut_Patterns.
- **Citation log (archived)** — moved out of active SOP; retained in registry for evidence preservation. No per-session append requirement. Record events that are genuinely novel; routine citations are redundant with Shortcuts_Full.

---

## What v5.4 changed from v5.2

- **V8 audit prompt reference:** `UNIVERSAL_AUDIT_PROMPT_v6.md` → `UNIVERSAL_AUDIT_PROMPT_v7.md` (Part H).
- **V8 inherited rules:** SOP-19 (rectifications-in-audit) and strengthened SOP-10 (BLOCKED self-test) added inline to Part H V8 description.
- **P24 added:** Audit-rectification-deferral pattern guard. *S271.*
- No changes to Part A/B/C/D/E operating principles, write gates, or session-start procedure.

## What v5.2 changed from v5.1

- **Master Plan version:** v93 → v95 (Part B authority line).
- **W9 duplicate label fixed:** Second W9 ("Reference grep on SHA/count change") renumbered W10; prior W10 ("Per-file skip reasons") renumbered W11.
- **Detector name in V10 table:** `WOS_PROMPTS_v3_10_TEST.py` (was v3_4 in v5.0).
- **P21 added:** Stale-reference-offering pattern guard (prior-session task flags offered without file verification). *S261.*

## What v5.0 removed from v4.5

- **Citation log append obligations (S2a, S3, S4, S5).** Replaced with a single close-step registry row (R1). The log added turns without reducing shortcuts.
- **Version history section.** Moved to registry Sessions_Detail.
- **Upgrade path section.** Not an operating instruction.
- **Relationship-to-other-documents section.** Redundant with registry Data_Sources_Reference.
- **P1–P7 (S27 chained-voice patterns).** Not cited in Sessions 26-31-cont-2. Archived to registry.
- **P11, P13, P14.** Same — no recent triggers.
- **"Structure" preamble.** Document is short enough to read without a TOC.
- **Session 31 closure note.** Historical; moved to registry.

## What v5.0 added

- **OP-3 Step 4 evaluation-type table** (the central fix for output efficiency).
- **P18 evaluation-as-text-grep** and **P19 displacement iteration** (both demonstrated in Session 31-continuation-2).
- **W9 — Reality-check first** (added Session 36 Apr 21 2026): audit/verify must read canonical files from disk before establishing baseline. S129.
- **Part I output efficiency rules** (E1–E8), making the implicit pro-speed stance explicit and rule-cited.

---

**Empirical caveat.** Your Experiment C data shows new SOP rules do not reliably change behavior via declaration. v5.0 addresses this by (a) giving evaluation a typed definition so "evaluate" stops being a flag the model sets without checking, (b) removing rules that added turns without preventing shortcuts, (c) making the pro-efficiency stance explicit so the next session's opener can cite E-rules directly instead of rebuilding them. The real behavior test is whether the next session opens, reads v5.0, and runs Task 0 detector baseline before asking Phase A questions. Document that outcome in Sessions_Detail.
